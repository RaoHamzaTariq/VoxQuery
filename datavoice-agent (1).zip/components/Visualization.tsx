import React from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
} from 'recharts';
import { formatCurrency, formatNumber } from '@/lib/utils';
import { QueryResult } from '@/lib/store';

interface VisualizationProps {
  type: 'bar' | 'line' | 'pie' | 'table' | 'number' | null;
  data: QueryResult | null;
}

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8', '#82ca9d'];

export function Visualization({ type, data }: VisualizationProps) {
  if (!data || !data.rows || data.rows.length === 0) {
    return (
      <div className="flex items-center justify-center h-full text-slate-500">
        No data to display
      </div>
    );
  }

  const chartData = data.rows;
  const keys = Object.keys(chartData[0]);
  const xAxisKey = keys[0]; // Assume first column is X-axis (e.g., date, category)
  const dataKey = keys[1]; // Assume second column is data (e.g., value, count)

  // 1. Single Number
  if (type === 'number') {
    const value = chartData[0][keys[0]];
    const isCurrency = typeof value === 'number' && value > 1000; // Heuristic
    
    return (
      <div className="flex flex-col items-center justify-center h-full">
        <span className="text-slate-400 text-lg font-medium uppercase tracking-wider mb-2">
          {keys[0].replace(/_/g, ' ')}
        </span>
        <span className="text-6xl font-bold text-white tracking-tight">
          {typeof value === 'number' 
            ? (isCurrency ? formatCurrency(value) : formatNumber(value)) 
            : value}
        </span>
      </div>
    );
  }

  // 2. Table
  if (type === 'table') {
    return (
      <div className="overflow-auto h-full w-full custom-scrollbar">
        <table className="w-full text-left border-collapse">
          <thead className="bg-slate-800/50 sticky top-0 z-10">
            <tr>
              {data.columns.map((col) => (
                <th key={col} className="p-3 text-xs font-semibold text-slate-400 uppercase tracking-wider border-b border-slate-700">
                  {col.replace(/_/g, ' ')}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800">
            {chartData.map((row, i) => (
              <tr key={i} className="hover:bg-white/5 transition-colors">
                {data.columns.map((col) => (
                  <td key={col} className="p-3 text-sm text-slate-300 font-mono">
                    {typeof row[col] === 'object' && row[col] !== null 
                      ? JSON.stringify(row[col]) 
                      : String(row[col])}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  }

  // 3. Charts
  return (
    <div className="w-full h-full min-h-[300px]">
      <ResponsiveContainer width="100%" height="100%">
        {type === 'bar' ? (
          <BarChart data={chartData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#334155" vertical={false} />
            <XAxis 
              dataKey={xAxisKey} 
              stroke="#94a3b8" 
              fontSize={12} 
              tickLine={false} 
              axisLine={false} 
            />
            <YAxis 
              stroke="#94a3b8" 
              fontSize={12} 
              tickLine={false} 
              axisLine={false}
              tickFormatter={(value) => formatNumber(value)}
            />
            <Tooltip 
              contentStyle={{ backgroundColor: '#1e293b', borderColor: '#334155', color: '#f8fafc' }}
              itemStyle={{ color: '#f8fafc' }}
              cursor={{ fill: 'rgba(255,255,255,0.05)' }}
            />
            <Bar dataKey={dataKey} fill="#3b82f6" radius={[4, 4, 0, 0]} />
          </BarChart>
        ) : type === 'line' ? (
          <LineChart data={chartData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#334155" vertical={false} />
            <XAxis 
              dataKey={xAxisKey} 
              stroke="#94a3b8" 
              fontSize={12} 
              tickLine={false} 
              axisLine={false} 
            />
            <YAxis 
              stroke="#94a3b8" 
              fontSize={12} 
              tickLine={false} 
              axisLine={false}
              tickFormatter={(value) => formatNumber(value)}
            />
            <Tooltip 
              contentStyle={{ backgroundColor: '#1e293b', borderColor: '#334155', color: '#f8fafc' }}
              itemStyle={{ color: '#f8fafc' }}
            />
            <Line 
              type="monotone" 
              dataKey={dataKey} 
              stroke="#3b82f6" 
              strokeWidth={3} 
              dot={{ fill: '#3b82f6', strokeWidth: 2 }} 
              activeDot={{ r: 6, fill: '#60a5fa' }}
            />
          </LineChart>
        ) : (
          <PieChart>
            <Pie
              data={chartData}
              cx="50%"
              cy="50%"
              labelLine={false}
              outerRadius={100}
              fill="#8884d8"
              dataKey={dataKey}
              nameKey={xAxisKey}
              label={({ name, percent }: { name?: string, percent?: number }) => `${name || ''} ${(percent ? (percent * 100).toFixed(0) : '0')}%`}
            >
              {chartData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip 
              contentStyle={{ backgroundColor: '#1e293b', borderColor: '#334155', color: '#f8fafc' }}
              itemStyle={{ color: '#f8fafc' }}
            />
          </PieChart>
        )}
      </ResponsiveContainer>
    </div>
  );
}
