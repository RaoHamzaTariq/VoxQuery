import React from 'react';
import { useStore } from '@/lib/store';
import { Clock, MessageSquare, ChevronRight } from 'lucide-react';
import { format } from 'date-fns';

export function HistoryView() {
  const { messages } = useStore();
  
  // Filter only user messages that have a corresponding assistant response
  const historyItems = messages.filter(m => m.role === 'user').reverse();

  return (
    <div className="flex-1 bg-[#0f172a] p-8 overflow-y-auto custom-scrollbar">
      <h2 className="text-2xl font-bold text-white mb-6 flex items-center gap-3">
        <Clock className="size-6 text-blue-500" />
        Query History
      </h2>

      <div className="space-y-4 max-w-4xl">
        {historyItems.length === 0 && (
          <div className="text-slate-500 italic">No history yet.</div>
        )}

        {historyItems.map((msg) => {
            const response = messages.find(m => m.id === (parseInt(msg.id) + 1).toString());
            
            return (
                <div key={msg.id} className="bg-[#1e293b] border border-slate-800 rounded-xl p-4 hover:border-blue-500/50 transition-colors group cursor-pointer">
                    <div className="flex justify-between items-start mb-2">
                        <div className="flex items-center gap-2 text-blue-400 font-medium">
                            <MessageSquare className="size-4" />
                            &quot;{msg.content}&quot;
                        </div>
                        <span className="text-xs text-slate-500">
                            {new Date(msg.timestamp).toLocaleString()}
                        </span>
                    </div>
                    
                    {response && (
                        <div className="pl-6 border-l-2 border-slate-700 mt-2">
                            <p className="text-slate-400 text-sm line-clamp-2">
                                {response.content}
                            </p>
                            {response.relatedQuery && (
                                <div className="mt-2 flex gap-2">
                                    <span className="text-xs bg-slate-800 text-emerald-400 px-2 py-1 rounded border border-slate-700 font-mono">
                                        SQL Executed
                                    </span>
                                    {response.chartType && (
                                        <span className="text-xs bg-slate-800 text-purple-400 px-2 py-1 rounded border border-slate-700 font-mono capitalize">
                                            {response.chartType} Chart
                                        </span>
                                    )}
                                </div>
                            )}
                        </div>
                    )}
                    
                    <div className="mt-3 flex justify-end opacity-0 group-hover:opacity-100 transition-opacity">
                        <button className="text-xs text-blue-400 flex items-center gap-1 hover:underline">
                            View Details <ChevronRight className="size-3" />
                        </button>
                    </div>
                </div>
            );
        })}
      </div>
    </div>
  );
}
