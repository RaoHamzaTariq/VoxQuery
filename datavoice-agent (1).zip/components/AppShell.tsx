'use client';

import React, { useEffect } from 'react';
import { useStore } from '@/lib/store';
import { Sidebar } from '@/components/Sidebar';
import { ConnectionForm } from '@/components/ConnectionForm';
import { SchemaBrowser } from '@/components/SchemaBrowser';
import { ChatInterface } from '@/components/ChatInterface';
import { HistoryView } from '@/components/HistoryView';
import { InsightCanvas } from '@/components/InsightCanvas';

export function AppShell() {
  const { activeView } = useStore();
  const [mounted, setMounted] = React.useState(false);

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setMounted(true);
  }, []);

  if (!mounted) return null;

  return (
    <div className="flex h-screen w-full bg-[#0f172a] text-slate-100 overflow-hidden font-sans">
      <Sidebar />
      
      <div className="flex-1 flex min-w-0">
        <main className="flex-1 flex overflow-hidden relative">
          {activeView === 'connection' && (
            <div className="flex-1 flex flex-col lg:flex-row p-6 gap-6 overflow-y-auto">
               <ConnectionForm />
               <SchemaBrowser />
            </div>
          )}

          {activeView === 'dashboard' && (
             <div className="flex-1 flex w-full h-full">
                <ChatInterface />
                <InsightCanvas />
             </div>
          )}

          {activeView === 'history' && (
             <HistoryView />
          )}
        </main>
      </div>
    </div>
  );
}
