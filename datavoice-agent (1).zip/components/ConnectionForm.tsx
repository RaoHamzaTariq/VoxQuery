import React, { useState } from 'react';
import { useStore, DatabaseConnection } from '@/lib/store';
import { Database, Lock, User, Server, Globe, CheckCircle, AlertCircle, Loader2 } from 'lucide-react';
import { cn } from '@/lib/utils';

export function ConnectionForm() {
  const { setConnection, setSchema, setActiveView } = useStore();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isMock, setIsMock] = useState(false);

  const [formData, setFormData] = useState<DatabaseConnection>({
    id: '1',
    name: 'My Database',
    type: 'mysql',
    host: '',
    port: 3306,
    database: '',
    username: '',
    password: '',
    ssl: true,
    isMock: false
  });

  const handleConnect = async () => {
    setLoading(true);
    setError(null);

    try {
      const connectionPayload = { ...formData, isMock };
      
      // 1. Test Connection & Get Schema
      const response = await fetch('/api/db/schema', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ connection: connectionPayload }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to connect');
      }

      // 2. Save Connection & Schema
      setConnection(connectionPayload);
      setSchema(data);
      setActiveView('dashboard');
      
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex-1 lg:max-w-[480px] bg-[#182334] rounded-xl border border-slate-800 flex flex-col shadow-xl overflow-hidden">
      <div className="p-5 border-b border-slate-800 flex justify-between items-center bg-white/5">
        <h3 className="font-bold text-white flex items-center gap-2">
          <Database className="text-blue-500 size-5" />
          Connection Settings
        </h3>
        <div className="flex items-center gap-2">
           <label className="text-xs text-slate-400 flex items-center gap-2 cursor-pointer">
              <input 
                type="checkbox" 
                checked={isMock} 
                onChange={(e) => setIsMock(e.target.checked)}
                className="rounded border-slate-700 bg-slate-900 text-blue-500 focus:ring-offset-0 focus:ring-2 focus:ring-blue-500/50 h-4 w-4"
              />
              Demo Mode
           </label>
        </div>
      </div>

      <div className="p-6 flex-1 overflow-y-auto custom-scrollbar space-y-5">
        {error && (
          <div className="bg-red-500/10 border border-red-500/20 text-red-400 p-3 rounded-lg text-sm flex items-center gap-2">
            <AlertCircle className="size-4" />
            {error}
          </div>
        )}

        <div className="flex gap-4">
          <label className="flex-1 flex flex-col gap-2">
            <span className="text-sm font-medium text-slate-300">Host</span>
            <div className="relative">
              <input
                disabled={isMock}
                value={isMock ? 'demo-db.internal' : formData.host}
                onChange={(e) => setFormData({ ...formData, host: e.target.value })}
                className="w-full bg-[#121b29] border border-slate-800 rounded-lg px-3 py-2.5 text-sm text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent placeholder-slate-600 outline-none transition-all pl-9 disabled:opacity-50"
                placeholder="e.g. 127.0.0.1"
              />
              <Server className="absolute left-2.5 top-2.5 text-slate-500 size-4" />
            </div>
          </label>
          <label className="w-24 flex flex-col gap-2">
            <span className="text-sm font-medium text-slate-300">Port</span>
            <input
              disabled={isMock}
              value={formData.port}
              onChange={(e) => setFormData({ ...formData, port: parseInt(e.target.value) || 3306 })}
              className="w-full bg-[#121b29] border border-slate-800 rounded-lg px-3 py-2.5 text-sm text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent placeholder-slate-600 outline-none transition-all text-center disabled:opacity-50"
            />
          </label>
        </div>

        <label className="flex flex-col gap-2">
          <span className="text-sm font-medium text-slate-300">Database Name</span>
          <div className="relative">
            <input
              disabled={isMock}
              value={isMock ? 'ecommerce_demo' : formData.database}
              onChange={(e) => setFormData({ ...formData, database: e.target.value })}
              className="w-full bg-[#121b29] border border-slate-800 rounded-lg px-3 py-2.5 text-sm text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent placeholder-slate-600 outline-none transition-all pl-9 disabled:opacity-50"
              placeholder="e.g. production_db"
            />
            <Database className="absolute left-2.5 top-2.5 text-slate-500 size-4" />
          </div>
        </label>

        <div className="pt-4 border-t border-slate-800/50">
          <h4 className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-4">Authentication</h4>
          <div className="space-y-4">
            <label className="flex flex-col gap-2">
              <span className="text-sm font-medium text-slate-300">Username</span>
              <div className="relative">
                <input
                  disabled={isMock}
                  value={isMock ? 'demo_user' : formData.username}
                  onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                  className="w-full bg-[#121b29] border border-slate-800 rounded-lg px-3 py-2.5 text-sm text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent placeholder-slate-600 outline-none transition-all pl-9 disabled:opacity-50"
                  placeholder="e.g. admin"
                />
                <User className="absolute left-2.5 top-2.5 text-slate-500 size-4" />
              </div>
            </label>
            <label className="flex flex-col gap-2">
              <span className="text-sm font-medium text-slate-300">Password</span>
              <div className="relative group">
                <input
                  disabled={isMock}
                  type="password"
                  value={isMock ? 'password123' : formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  className="w-full bg-[#121b29] border border-slate-800 rounded-lg px-3 py-2.5 text-sm text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent placeholder-slate-600 outline-none transition-all pl-9 disabled:opacity-50"
                  placeholder="••••••••"
                />
                <Lock className="absolute left-2.5 top-2.5 text-slate-500 size-4" />
              </div>
            </label>
          </div>
        </div>
      </div>

      <div className="p-5 border-t border-slate-800 bg-[#101722]/30 flex gap-3">
        <button 
          onClick={handleConnect}
          disabled={loading}
          className="flex-[2] bg-blue-600 hover:bg-blue-500 text-white py-2.5 px-4 rounded-lg text-sm font-medium shadow-lg shadow-blue-900/20 transition-all flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {loading ? (
            <Loader2 className="size-4 animate-spin" />
          ) : (
            <CheckCircle className="size-4" />
          )}
          {loading ? 'Connecting...' : 'Save & Connect'}
        </button>
      </div>
    </div>
  );
}
