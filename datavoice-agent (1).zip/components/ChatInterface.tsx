import React, { useEffect, useRef, useState } from 'react';
import { useStore } from '@/lib/store';
import { useLiveGemini } from '@/hooks/use-live-gemini';
import { Mic, Terminal, Edit2, MicOff, Power } from 'lucide-react';
import { cn } from '@/lib/utils';

export function ChatInterface() {
  const { 
    messages, 
    connection, 
  } = useStore();
  
  const { 
    isConnected,
    isListening,
    connect,
    disconnect,
    startRecording,
    stopRecording
  } = useLiveGemini();

  const [showSqlPreview, setShowSqlPreview] = useState(true);

  const toggleConnection = () => {
    if (isConnected) {
      disconnect();
    } else {
      if (!connection) {
        alert("Please connect to a database first.");
        return;
      }
      connect();
    }
  };

  const toggleRecording = () => {
    if (isListening) {
      stopRecording();
    } else {
      startRecording();
    }
  };

  // Get the last user message to display as the main prompt
  const lastUserMessage = messages.slice().reverse().find(m => m.role === 'user');
  const lastAssistantMessage = messages.slice().reverse().find(m => m.role === 'assistant');

  return (
    <div className="flex-1 flex flex-col h-full relative overflow-hidden bg-[#0f172a] items-center justify-center">
      
      {/* Center Content */}
      <div className="flex flex-col items-center justify-center w-full max-w-2xl px-6 z-10 -mt-20">
        
        {/* Visualizer Bars (Static for now, animate when listening) */}
        <div className="flex items-center justify-center gap-1 h-12 mb-8">
          {[1, 2, 3, 4, 5].map((i) => (
            <div
              key={i}
              className={cn(
                "w-1.5 bg-emerald-400 rounded-full transition-all duration-300",
                isListening ? "animate-pulse h-8" : "h-4 opacity-30"
              )}
              style={{
                animationDelay: `${i * 0.1}s`
              }}
            />
          ))}
        </div>

        {/* Main Text Prompt */}
        <h1 className="text-4xl md:text-5xl font-bold text-white text-center leading-tight mb-12 tracking-tight">
          {lastUserMessage ? (
            `"${lastUserMessage.content}"`
          ) : (
            <span className="opacity-50">&quot;Show me our monthly revenue for the last year&quot;</span>
          )}
        </h1>

        {/* Big Mic Button */}
        <button
          onClick={toggleRecording}
          disabled={!isConnected}
          className={cn(
            "size-24 rounded-full flex items-center justify-center transition-all shadow-2xl relative group",
            isListening 
              ? "bg-red-500 text-white animate-pulse ring-8 ring-red-500/20" 
              : "bg-emerald-500 text-white hover:bg-emerald-400 hover:scale-105 active:scale-95 ring-8 ring-emerald-500/20"
          )}
        >
          {isListening ? <MicOff className="size-10" /> : <Mic className="size-10" />}
          
          {/* Tooltip */}
          <span className="absolute -bottom-10 text-sm text-slate-400 opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
            {isConnected ? (isListening ? "Stop Listening" : "Tap to Speak") : "Connect First"}
          </span>
        </button>

        {!isConnected && (
            <button 
            onClick={toggleConnection}
            className="mt-8 px-6 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-full text-sm font-medium transition-all flex items-center gap-2 border border-slate-700"
            >
                <Power className="size-4" />
                Connect to Live Agent
            </button>
        )}

      </div>

      {/* SQL Preview Card (Bottom) */}
      {lastAssistantMessage?.relatedQuery?.sql && showSqlPreview && (
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 w-full max-w-2xl px-6 animate-in slide-in-from-bottom-10 fade-in duration-500">
          <div className="bg-[#1e293b] border border-slate-800 rounded-xl overflow-hidden shadow-2xl">
            <div className="flex items-center justify-between px-4 py-2 bg-[#0f172a] border-b border-slate-800">
              <div className="flex items-center gap-2 text-xs font-medium text-slate-400">
                <Terminal className="size-3" />
                SQL PREVIEW
              </div>
              <div className="flex items-center gap-3">
                 <button className="text-slate-400 hover:text-white transition-colors">
                    <div className="size-3 border border-slate-600 rounded-sm" />
                 </button>
                 <button className="flex items-center gap-1.5 px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs rounded transition-colors">
                    <Edit2 className="size-3" />
                    Edit
                 </button>
              </div>
            </div>
            <div className="p-4 bg-[#0f172a]/50 font-mono text-sm leading-relaxed">
              <div className="text-emerald-400">
                <span className="text-yellow-500">SELECT</span> month, <span className="text-blue-400">SUM</span>(revenue)
              </div>
              <div className="text-emerald-400">
                <span className="text-yellow-500">FROM</span> Sales
              </div>
              <div className="text-emerald-400">
                <span className="text-yellow-500">WHERE</span> date &ge; <span className="text-blue-400">DATE</span>(<span className="text-green-300">&apos;now&apos;</span>, <span className="text-green-300">&apos;-1 year&apos;</span>)
              </div>
              <div className="text-emerald-400">
                <span className="text-yellow-500">GROUP BY</span> month;
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
