import React from 'react';
import { Share2, Download, Sparkles, TrendingUp, X } from 'lucide-react';
import { Visualization } from '@/components/Visualization';
import { useStore } from '@/lib/store';

export function InsightCanvas() {
  const { messages } = useStore();
  const lastAssistantMessage = messages.slice().reverse().find(m => m.role === 'assistant' && (m.relatedQuery || m.chartType));

  // Mock data for the "December Spike" example if no real data exists yet
  const mockData = {
    rows: [
      { month: 'JAN', revenue: 65000 },
      { month: 'FEB', revenue: 72000 },
      { month: 'MAR', revenue: 68000 },
      { month: 'APR', revenue: 85000 },
      { month: 'MAY', revenue: 92000 },
      { month: 'JUN', revenue: 98000 },
      { month: 'JUL', revenue: 105000 },
      { month: 'AUG', revenue: 112000 },
      { month: 'SEP', revenue: 108000 },
      { month: 'OCT', revenue: 125000 },
      { month: 'NOV', revenue: 145000 },
      { month: 'DEC', revenue: 195000 },
    ],
    columns: ['month', 'revenue'],
    executionTime: 0,
    sql: ''
  };

  const displayData = lastAssistantMessage?.relatedQuery || mockData;
  const chartType = lastAssistantMessage?.chartType || 'bar';

  return (
    <div className="w-[400px] bg-[#1e293b] border-l border-slate-800 flex flex-col h-full">
      {/* Header */}
      <div className="p-6 border-b border-slate-800 flex justify-between items-center">
        <h2 className="text-lg font-semibold text-white">Insight Canvas</h2>
        <div className="flex gap-2">
          <button className="p-2 text-slate-400 hover:text-white transition-colors">
            <Share2 className="size-5" />
          </button>
          <button className="p-2 text-slate-400 hover:text-white transition-colors">
            <Download className="size-5" />
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-6 space-y-6 custom-scrollbar">
        {/* Toggle */}
        <div className="flex bg-[#0f172a] p-1 rounded-lg w-fit">
          <button className="px-4 py-1.5 bg-[#1e293b] text-white text-sm font-medium rounded shadow-sm">Chart</button>
          <button className="px-4 py-1.5 text-slate-400 text-sm font-medium hover:text-white transition-colors">Data Table</button>
        </div>

        {/* Main Chart Card */}
        <div className="bg-[#0f172a] rounded-2xl p-6 border border-slate-800">
          <div className="mb-6">
            <p className="text-slate-400 text-sm mb-1">Total Revenue (Last 12mo)</p>
            <div className="flex items-baseline gap-3">
              <h3 className="text-3xl font-bold text-white">$1,240,500</h3>
              <span className="text-emerald-400 text-sm font-medium flex items-center gap-1">
                <TrendingUp className="size-3" />
                +12.5%
              </span>
            </div>
          </div>

          <div className="h-[200px] w-full">
             <Visualization type={chartType} data={displayData} />
          </div>
        </div>

        {/* Auto-Insights */}
        <div>
          <h4 className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-4">Auto-Insights</h4>
          <div className="space-y-3">
            {/* Insight 1 */}
            <div className="bg-[#0f172a] p-4 rounded-xl border border-slate-800 relative group">
              <button className="absolute top-2 right-2 text-slate-500 hover:text-white opacity-0 group-hover:opacity-100 transition-opacity">
                <X className="size-4" />
              </button>
              <div className="flex gap-3">
                <div className="mt-1">
                  <Sparkles className="size-5 text-blue-400" />
                </div>
                <div>
                  <h5 className="text-sm font-medium text-white mb-1">December Spike Detected</h5>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    Revenue spiked <span className="text-white font-medium">40%</span> in December compared to November, driven primarily by the &quot;Holiday Bundle&quot; product category.
                  </p>
                </div>
              </div>
            </div>

            {/* Insight 2 */}
            <div className="bg-[#0f172a] p-4 rounded-xl border border-slate-800 relative group">
              <div className="flex gap-3">
                <div className="mt-1">
                  <TrendingUp className="size-5 text-emerald-400" />
                </div>
                <div>
                  <h5 className="text-sm font-medium text-white mb-1">Steady Q4 Growth</h5>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    Overall Q4 performance exceeded projections by <span className="text-white font-medium">15%</span>.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Footer Input */}
      <div className="p-6 border-t border-slate-800 bg-[#1e293b]">
        <button className="w-full bg-[#0f172a] hover:bg-slate-900 border border-slate-700 text-slate-300 py-3 px-4 rounded-xl text-sm font-medium transition-all flex justify-between items-center group">
          Ask follow-up question
          <span className="group-hover:translate-x-1 transition-transform">→</span>
        </button>
      </div>
    </div>
  );
}
