import React from 'react';
import { useStore } from '@/lib/store';
import { Database, FolderOpen, Table, Key, Link as LinkIcon, Search, ChevronRight, ChevronDown } from 'lucide-react';
import { cn } from '@/lib/utils';

export function SchemaBrowser() {
  const { schema } = useStore();
  const [expandedTables, setExpandedTables] = React.useState<Record<string, boolean>>({});

  const toggleTable = (tableName: string) => {
    setExpandedTables(prev => ({
      ...prev,
      [tableName]: !prev[tableName]
    }));
  };

  return (
    <div className="flex-[2] bg-[#182334] rounded-xl border border-slate-800 flex flex-col shadow-xl overflow-hidden min-h-[500px]">
      <div className="p-4 border-b border-slate-800 flex justify-between items-center bg-white/5">
        <div className="flex items-center gap-3">
          <h3 className="font-bold text-white flex items-center gap-2">
            <Database className="text-emerald-400 size-5" />
            Schema Browser
          </h3>
          <span className="text-slate-500 text-sm">|</span>
          <span className="text-slate-400 text-sm">public</span>
        </div>
        <div className="relative w-64">
          <Search className="absolute left-2.5 top-2 text-slate-500 size-4" />
          <input
            className="w-full bg-[#121b29] border border-slate-800 rounded-lg pl-9 pr-3 py-1.5 text-sm text-white focus:border-blue-500 focus:ring-0 placeholder-slate-600 outline-none transition-colors"
            placeholder="Search tables..."
            type="text"
          />
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4 custom-scrollbar bg-[#101722]/20 relative">
        <div className="absolute inset-0 opacity-[0.03] pointer-events-none" style={{ backgroundImage: 'radial-gradient(#ffffff 1px, transparent 1px)', backgroundSize: '20px 20px' }}></div>
        
        <div className="relative z-10 space-y-1">
          {/* Root Item */}
          <div className="flex items-center gap-2 py-1.5 px-2 hover:bg-white/5 rounded group cursor-pointer">
            <ChevronDown className="text-slate-400 size-5" />
            <FolderOpen className="text-blue-400 size-5" />
            <span className="text-slate-200 text-sm font-medium">public</span>
            <span className="text-xs text-slate-600 ml-auto group-hover:text-slate-400">Schema</span>
          </div>

          {/* Tables Group */}
          <div className="pl-6 space-y-1">
            {schema.length === 0 && (
                <div className="text-slate-500 text-sm italic py-2">No schema loaded. Connect to a database to view tables.</div>
            )}
            
            {schema.map((table) => (
              <div key={table.tableName}>
                <div 
                  onClick={() => toggleTable(table.tableName)}
                  className={cn(
                    "flex items-center gap-2 py-1.5 px-2 rounded group cursor-pointer transition-colors",
                    expandedTables[table.tableName] ? "bg-blue-500/10 border-l-2 border-blue-500" : "hover:bg-white/5 border-l-2 border-transparent"
                  )}
                >
                  {expandedTables[table.tableName] ? (
                    <ChevronDown className="text-slate-400 size-5" />
                  ) : (
                    <ChevronRight className="text-slate-500 size-5" />
                  )}
                  <Table className={cn("size-[18px]", expandedTables[table.tableName] ? "text-emerald-400" : "text-slate-500")} />
                  <span className={cn("text-sm font-medium", expandedTables[table.tableName] ? "text-white" : "text-slate-400")}>
                    {table.tableName}
                  </span>
                </div>

                {/* Columns */}
                {expandedTables[table.tableName] && (
                  <div className="pl-8 pt-1 pb-2 space-y-0.5 border-l border-slate-800 ml-3.5">
                    {table.columns.map((col) => (
                      <div key={col.name} className="flex items-center justify-between py-1 px-3 hover:bg-white/5 rounded cursor-default group">
                        <div className="flex items-center gap-2">
                          {col.isPrimaryKey && <Key className="text-yellow-500 size-[14px]" />}
                          {!col.isPrimaryKey && !col.isForeignKey && <span className="w-3.5"></span>}
                          <span className="text-slate-300 text-sm">{col.name}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          {col.isForeignKey && <LinkIcon className="text-slate-600 size-[14px]" />}
                          <span className="text-[10px] font-mono bg-slate-800 text-slate-400 px-1.5 py-0.5 rounded border border-slate-700">
                            {col.type}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="p-3 bg-[#101722]/50 border-t border-slate-800 text-xs text-slate-500 flex justify-between">
        <span>Schema size: {schema.length} tables</span>
        <span>Last introspected: Just now</span>
      </div>
    </div>
  );
}
