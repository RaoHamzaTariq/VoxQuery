import React from 'react';
import { useStore } from '@/lib/store';
import { cn } from '@/lib/utils';
import { LayoutDashboard, History, Plus, Database, Users, ShoppingBag, BarChart3, Settings } from 'lucide-react';

export function Sidebar() {
  const { activeView, setActiveView } = useStore();

  return (
    <aside className="w-64 bg-[#0f172a] border-r border-slate-800 flex flex-col h-full shrink-0">
      {/* Logo Area */}
      <div className="p-6">
        <div className="flex items-center gap-3 mb-1">
          <div className="size-8 bg-gradient-to-br from-emerald-400 to-blue-500 rounded-lg flex items-center justify-center text-white shadow-lg shadow-emerald-500/20">
            <BarChart3 className="size-5" />
          </div>
          <h1 className="text-xl font-bold text-white tracking-tight">DataVoice</h1>
        </div>
        <div className="flex items-center gap-2 px-1">
          <div className="size-2 bg-emerald-500 rounded-full animate-pulse" />
          <span className="text-xs text-slate-400 font-medium">Connected: Prod DB</span>
        </div>
      </div>

      {/* New Query Button */}
      <div className="px-6 mb-6">
        <button 
          onClick={() => setActiveView('dashboard')}
          className="w-full bg-[#1e293b] hover:bg-[#2d3b52] text-emerald-400 border border-emerald-500/20 py-3 rounded-xl font-medium transition-all flex items-center justify-center gap-2 group shadow-sm"
        >
          <div className="bg-emerald-500/20 p-1 rounded-md group-hover:bg-emerald-500/30 transition-colors">
             <Plus className="size-4" />
          </div>
          New Query
        </button>
      </div>

      {/* Navigation */}
      <div className="px-4 space-y-1 mb-8">
        <button
          onClick={() => setActiveView('dashboard')}
          className={cn(
            "w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors",
            activeView === 'dashboard' ? "text-white bg-white/5" : "text-slate-400 hover:text-white hover:bg-white/5"
          )}
        >
          <LayoutDashboard className="size-4" />
          Dashboard
        </button>
        <button
          onClick={() => setActiveView('history')}
          className={cn(
            "w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors",
            activeView === 'history' ? "text-white bg-white/5" : "text-slate-400 hover:text-white hover:bg-white/5"
          )}
        >
          <History className="size-4" />
          History
        </button>
      </div>

      {/* Schema Explorer */}
      <div className="px-6 mb-8">
        <h3 className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-4">Schema Explorer</h3>
        <div className="space-y-1">
          <button className="w-full flex items-center gap-3 px-2 py-1.5 text-slate-400 hover:text-white transition-colors text-sm group">
            <span className="text-slate-600 group-hover:text-slate-400">›</span>
            <Database className="size-4 text-emerald-500/80" />
            Sales
          </button>
          <button className="w-full flex items-center gap-3 px-2 py-1.5 text-slate-400 hover:text-white transition-colors text-sm group">
            <span className="text-slate-600 group-hover:text-slate-400">›</span>
            <Users className="size-4 text-blue-500/80" />
            Users
          </button>
          <button className="w-full flex items-center gap-3 px-2 py-1.5 text-slate-400 hover:text-white transition-colors text-sm group">
            <span className="text-slate-600 group-hover:text-slate-400">›</span>
            <ShoppingBag className="size-4 text-purple-500/80" />
            Products
          </button>
        </div>
      </div>

      {/* Recent Queries */}
      <div className="px-6 flex-1 overflow-y-auto custom-scrollbar">
        <h3 className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-4">Recent Queries</h3>
        <div className="space-y-3">
          <button className="text-left text-sm text-slate-400 hover:text-white transition-colors block w-full truncate">
            Top 5 users by spend
          </button>
          <button className="text-left text-sm text-slate-400 hover:text-white transition-colors block w-full truncate">
            Inventory count {'<'} 10
          </button>
          <button className="text-left text-sm text-slate-400 hover:text-white transition-colors block w-full truncate">
            Q3 Revenue growth
          </button>
        </div>
      </div>

      {/* User Profile */}
      <div className="p-4 border-t border-slate-800 mt-auto">
        <div className="flex items-center gap-3 p-2 rounded-xl hover:bg-white/5 cursor-pointer transition-colors group">
          <div className="size-10 rounded-full bg-slate-700 flex items-center justify-center text-slate-300 font-medium">
            AM
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-white truncate">Alex Morgan</p>
            <p className="text-xs text-slate-500 truncate">Data Analyst</p>
          </div>
          <Settings className="size-4 text-slate-500 group-hover:text-white transition-colors" />
        </div>
      </div>
    </aside>
  );
}
