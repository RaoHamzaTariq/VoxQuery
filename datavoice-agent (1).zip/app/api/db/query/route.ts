import { NextResponse } from 'next/server';
import { executeQuery } from '@/lib/db-service';

export async function POST(req: Request) {
  try {
    const { connection, query } = await req.json();
    
    if (!connection || !query) {
      return NextResponse.json({ error: 'Missing connection or query' }, { status: 400 });
    }

    const result = await executeQuery(connection, query);
    return NextResponse.json(result);
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
