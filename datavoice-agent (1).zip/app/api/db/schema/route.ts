import { NextResponse } from 'next/server';
import { getSchema } from '@/lib/db-service';

export async function POST(req: Request) {
  try {
    const { connection } = await req.json();
    
    if (!connection) {
      return NextResponse.json({ error: 'Missing connection details' }, { status: 400 });
    }

    const schema = await getSchema(connection);
    return NextResponse.json(schema);
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
