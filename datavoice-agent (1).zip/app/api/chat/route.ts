import { Groq } from 'groq-sdk';
import { NextResponse } from 'next/server';
import { executeQuery } from '@/lib/db-service';

export async function POST(req: Request) {
  try {
    const groq = new Groq({ apiKey: process.env.GROQ_API_KEY });
    const { message, connection, schema, history } = await req.json();

    if (!message || !connection) {
      return NextResponse.json({ error: 'Missing message or connection' }, { status: 400 });
    }

    // System Instruction
    const systemInstruction = `
      You are DataVoice, an expert Data Analyst and Database Administrator.
      Your goal is to help users query their MySQL database using natural language.
      
      Current Database Schema:
      ${JSON.stringify(schema, null, 2)}
      
      Rules:
      1. Always use valid MySQL syntax.
      2. When the user asks for data, generate a SQL query to fetch it.
      3. If the user asks for a visualization (chart, graph), specify the chart type in your response.
      4. Be concise and professional but friendly.
      5. If the query is destructive (DELETE, DROP, TRUNCATE), ask for confirmation first (unless the user explicitly says "force" or "I confirm").
      6. If the user's request is ambiguous, ask clarifying questions.
      7. Format numbers as currency or compact numbers where appropriate in your text response.
      8. TODAY'S DATE is ${new Date().toISOString().split('T')[0]}.
      
      Response Format:
      You can call the 'run_sql_query' tool to execute queries.
      After getting the data, summarize the findings in natural language.
    `;

    // Define Tools
    const tools = [
      {
        type: "function" as const,
        function: {
          name: "run_sql_query",
          description: "Executes a MySQL query against the connected database.",
          parameters: {
            type: "object",
            properties: {
              query: {
                type: "string",
                description: "The SQL query to execute.",
              },
            },
            required: ["query"],
          },
        },
      },
    ];

    const messages = [
      { role: "system", content: systemInstruction },
      ...history.map((msg: any) => ({
        role: msg.role === 'assistant' ? 'assistant' : 'user',
        content: msg.content,
      })),
      { role: "user", content: message },
    ];

    // 1. Initial Call
    const chatCompletion = await groq.chat.completions.create({
      messages: messages as any,
      model: "llama3-70b-8192",
      tools: tools,
      tool_choice: "auto",
      max_tokens: 1024,
    });

    const responseMessage = chatCompletion.choices[0].message;
    const toolCalls = responseMessage.tool_calls;

    let queryResult = null;
    let sqlQuery = '';
    let finalResponseText = responseMessage.content || '';

    // 2. Handle Tool Calls
    if (toolCalls) {
      messages.push(responseMessage); // Add assistant's tool call message to history

      for (const toolCall of toolCalls) {
        if (toolCall.function.name === "run_sql_query") {
          const functionArgs = JSON.parse(toolCall.function.arguments);
          sqlQuery = functionArgs.query;
          console.log('Executing SQL (Groq):', sqlQuery);

          try {
            const result = await executeQuery(connection, sqlQuery);
            queryResult = result;

            messages.push({
              tool_call_id: toolCall.id,
              role: "tool",
              name: "run_sql_query",
              content: JSON.stringify(result),
            });
          } catch (error: any) {
            console.error('SQL Execution Error:', error);
            messages.push({
              tool_call_id: toolCall.id,
              role: "tool",
              name: "run_sql_query",
              content: JSON.stringify({ error: error.message }),
            });
          }
        }
      }

      // 3. Second Call (Get final response)
      const secondResponse = await groq.chat.completions.create({
        messages: messages as any,
        model: "llama3-70b-8192",
      });

      finalResponseText = secondResponse.choices[0].message.content || '';
    }

    // Determine Chart Type based on data and response text
    let chartType = null;
    const result = queryResult as any;
    if (result && result.rows && result.rows.length > 0) {
      const lowerText = finalResponseText.toLowerCase();
      const rowCount = result.rows.length;
      const colCount = result.columns.length;

      if (lowerText.includes('chart') || lowerText.includes('graph') || lowerText.includes('plot') || lowerText.includes('trend')) {
        if (rowCount > 1 && (lowerText.includes('bar') || lowerText.includes('column'))) {
          chartType = 'bar';
        } else if (rowCount > 1 && (lowerText.includes('line') || lowerText.includes('trend'))) {
          chartType = 'line';
        } else if (lowerText.includes('pie') || lowerText.includes('distribution')) {
          chartType = 'pie';
        } else {
          // Default heuristics
          if (rowCount > 10) chartType = 'line';
          else chartType = 'bar';
        }
      } else if (rowCount === 1 && colCount === 1) {
        chartType = 'number';
      } else {
        chartType = 'table';
      }
    }

    return NextResponse.json({
      text: finalResponseText,
      sql: sqlQuery,
      data: queryResult,
      chartType,
    });

  } catch (error: any) {
    console.error('Chat API Error:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
