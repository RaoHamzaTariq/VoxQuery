import mysql from 'mysql2/promise';

// Mock Data for Demo Mode
const MOCK_DATA = {
  orders: [
    { id: 1001, customer_id: 1, total_amount: 1250.00, status: 'completed', created_at: '2023-01-15' },
    { id: 1002, customer_id: 2, total_amount: 450.50, status: 'pending', created_at: '2023-01-16' },
    { id: 1003, customer_id: 1, total_amount: 2100.00, status: 'completed', created_at: '2023-02-10' },
    { id: 1004, customer_id: 3, total_amount: 89.99, status: 'cancelled', created_at: '2023-02-12' },
    { id: 1005, customer_id: 2, total_amount: 675.00, status: 'completed', created_at: '2023-03-05' },
    { id: 1006, customer_id: 4, total_amount: 3200.00, status: 'completed', created_at: '2023-03-20' },
    { id: 1007, customer_id: 1, total_amount: 150.00, status: 'completed', created_at: '2023-04-01' },
    { id: 1008, customer_id: 3, total_amount: 500.00, status: 'pending', created_at: '2023-04-15' },
    { id: 1009, customer_id: 5, total_amount: 1200.00, status: 'completed', created_at: '2023-05-10' },
    { id: 1010, customer_id: 2, total_amount: 850.00, status: 'completed', created_at: '2023-06-01' },
  ],
  customers: [
    { id: 1, name: 'Acme Corp', region: 'North America', segment: 'Enterprise' },
    { id: 2, name: 'Globex Inc', region: 'Europe', segment: 'SMB' },
    { id: 3, name: 'Soylent Corp', region: 'Asia', segment: 'Enterprise' },
    { id: 4, name: 'Initech', region: 'North America', segment: 'SMB' },
    { id: 5, name: 'Umbrella Corp', region: 'Europe', segment: 'Enterprise' },
  ],
  products: [
    { id: 1, name: 'Widget A', category: 'Hardware', price: 50.00 },
    { id: 2, name: 'Widget B', category: 'Hardware', price: 75.00 },
    { id: 3, name: 'Service X', category: 'Software', price: 100.00 },
    { id: 4, name: 'Service Y', category: 'Software', price: 200.00 },
  ]
};

export async function executeQuery(connectionConfig: any, query: string) {
  if (connectionConfig.isMock) {
    return executeMockQuery(query);
  }

  try {
    const connection = await mysql.createConnection({
      host: connectionConfig.host,
      user: connectionConfig.username,
      password: connectionConfig.password,
      database: connectionConfig.database,
      port: connectionConfig.port,
      ssl: connectionConfig.ssl ? { rejectUnauthorized: false } : undefined,
    });

    const [rows, fields] = await connection.execute(query);
    await connection.end();

    return {
      rows,
      columns: fields ? fields.map((f) => f.name) : [],
    };
  } catch (error: any) {
    console.error('Database Error:', error);
    throw new Error(error.message || 'Database connection failed');
  }
}

function executeMockQuery(query: string) {
  // Very basic mock query parser for demo purposes
  const lowerQuery = query.toLowerCase();
  
  // Simulate delay
  return new Promise((resolve) => {
    setTimeout(() => {
      if (lowerQuery.includes('select') && lowerQuery.includes('orders')) {
        if (lowerQuery.includes('count')) {
           resolve({ rows: [{ count: MOCK_DATA.orders.length }], columns: ['count'] });
        }
        if (lowerQuery.includes('sum') && lowerQuery.includes('total_amount')) {
           const total = MOCK_DATA.orders.reduce((acc, order) => acc + order.total_amount, 0);
           resolve({ rows: [{ total_revenue: total }], columns: ['total_revenue'] });
        }
        // Default to returning all orders
        resolve({ 
          rows: MOCK_DATA.orders, 
          columns: Object.keys(MOCK_DATA.orders[0]) 
        });
      } else if (lowerQuery.includes('select') && lowerQuery.includes('customers')) {
        resolve({ 
          rows: MOCK_DATA.customers, 
          columns: Object.keys(MOCK_DATA.customers[0]) 
        });
      } else {
        // Fallback mock response for complex queries
        resolve({
          rows: MOCK_DATA.orders.slice(0, 5),
          columns: Object.keys(MOCK_DATA.orders[0])
        });
      }
    }, 500);
  });
}

export async function getSchema(connectionConfig: any) {
  if (connectionConfig.isMock) {
    return [
      {
        tableName: 'orders',
        columns: [
          { name: 'id', type: 'int', isPrimaryKey: true, isForeignKey: false },
          { name: 'customer_id', type: 'int', isPrimaryKey: false, isForeignKey: true },
          { name: 'total_amount', type: 'decimal', isPrimaryKey: false, isForeignKey: false },
          { name: 'status', type: 'varchar', isPrimaryKey: false, isForeignKey: false },
          { name: 'created_at', type: 'datetime', isPrimaryKey: false, isForeignKey: false },
        ]
      },
      {
        tableName: 'customers',
        columns: [
          { name: 'id', type: 'int', isPrimaryKey: true, isForeignKey: false },
          { name: 'name', type: 'varchar', isPrimaryKey: false, isForeignKey: false },
          { name: 'region', type: 'varchar', isPrimaryKey: false, isForeignKey: false },
          { name: 'segment', type: 'varchar', isPrimaryKey: false, isForeignKey: false },
        ]
      },
      {
        tableName: 'products',
        columns: [
          { name: 'id', type: 'int', isPrimaryKey: true, isForeignKey: false },
          { name: 'name', type: 'varchar', isPrimaryKey: false, isForeignKey: false },
          { name: 'category', type: 'varchar', isPrimaryKey: false, isForeignKey: false },
          { name: 'price', type: 'decimal', isPrimaryKey: false, isForeignKey: false },
        ]
      }
    ];
  }

  try {
    const connection = await mysql.createConnection({
      host: connectionConfig.host,
      user: connectionConfig.username,
      password: connectionConfig.password,
      database: connectionConfig.database,
      port: connectionConfig.port,
      ssl: connectionConfig.ssl ? { rejectUnauthorized: false } : undefined,
    });

    // Get tables
    const [tables]: any = await connection.execute('SHOW TABLES');
    const tableNames = tables.map((t: any) => Object.values(t)[0]);

    const schema = [];

    for (const tableName of tableNames) {
      const [columns]: any = await connection.execute(`DESCRIBE ${tableName}`);
      schema.push({
        tableName,
        columns: columns.map((col: any) => ({
          name: col.Field,
          type: col.Type,
          isPrimaryKey: col.Key === 'PRI',
          isForeignKey: col.Key === 'MUL', // Simplified assumption
        }))
      });
    }

    await connection.end();
    return schema;
  } catch (error: any) {
    console.error('Schema Error:', error);
    throw new Error(error.message || 'Failed to fetch schema');
  }
}
