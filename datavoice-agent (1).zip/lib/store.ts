import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export interface DatabaseConnection {
  id: string;
  name: string;
  type: 'mysql' | 'postgres';
  host: string;
  port: number;
  database: string;
  username: string;
  password?: string; // Only stored in memory or secure storage, not persisted to local storage if possible
  ssl: boolean;
  isMock?: boolean;
}

export interface TableSchema {
  tableName: string;
  columns: {
    name: string;
    type: string;
    isPrimaryKey: boolean;
    isForeignKey: boolean;
  }[];
}

export interface QueryResult {
  columns: string[];
  rows: any[];
  executionTime: number;
  sql: string;
}

export interface Message {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: number;
  relatedQuery?: QueryResult;
  chartType?: 'bar' | 'line' | 'pie' | 'table' | 'number';
  chartConfig?: any;
}

interface AppState {
  // Connection
  connection: DatabaseConnection | null;
  setConnection: (conn: DatabaseConnection | null) => void;
  
  // Schema
  schema: TableSchema[];
  setSchema: (schema: TableSchema[]) => void;
  
  // Chat
  messages: Message[];
  addMessage: (msg: Message) => void;
  clearMessages: () => void;
  isProcessing: boolean;
  setIsProcessing: (isProcessing: boolean) => void;
  
  // Voice
  isListening: boolean;
  setIsListening: (isListening: boolean) => void;
  isSpeaking: boolean;
  setIsSpeaking: (isSpeaking: boolean) => void;
  
  // UI
  activeView: 'dashboard' | 'connection' | 'history';
  setActiveView: (view: 'dashboard' | 'connection' | 'history') => void;
}

export const useStore = create<AppState>()(
  persist(
    (set) => ({
      connection: null,
      setConnection: (conn) => set({ connection: conn }),
      
      schema: [],
      setSchema: (schema) => set({ schema }),
      
      messages: [],
      addMessage: (msg) => set((state) => ({ messages: [...state.messages, msg] })),
      clearMessages: () => set({ messages: [] }),
      isProcessing: false,
      setIsProcessing: (isProcessing) => set({ isProcessing }),
      
      isListening: false,
      setIsListening: (isListening) => set({ isListening }),
      isSpeaking: false,
      setIsSpeaking: (isSpeaking) => set({ isSpeaking }),
      
      activeView: 'connection', // Start at connection screen
      setActiveView: (view) => set({ activeView: view }),
    }),
    {
      name: 'datavoice-storage',
      partialize: (state) => ({ 
        connection: state.connection,
        schema: state.schema,
        messages: state.messages 
      }),
    }
  )
);
