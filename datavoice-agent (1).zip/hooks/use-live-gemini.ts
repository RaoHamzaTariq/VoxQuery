import { useEffect, useRef, useState, useCallback } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality, Type } from '@google/genai';
import { useStore } from '@/lib/store';

export function useLiveGemini() {
  const { connection, addMessage, schema } = useStore();
  const [isConnected, setIsConnected] = useState(false);
  const [isListening, setIsListening] = useState(false);
  
  // Refs for audio handling
  const audioContextRef = useRef<AudioContext | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const processorRef = useRef<ScriptProcessorNode | null>(null);
  const sourceRef = useRef<MediaStreamAudioSourceNode | null>(null);
  const sessionRef = useRef<any>(null);
  const audioQueueRef = useRef<Float32Array[]>([]);
  const isPlayingRef = useRef(false);
  const nextPlayTimeRef = useRef(0);

  // ... (audio context initialization remains same)

  // Initialize Audio Context
  const ensureAudioContext = useCallback(() => {
    if (!audioContextRef.current) {
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({
        sampleRate: 24000, // Gemini output is often 24kHz
      });
    }
    if (audioContextRef.current.state === 'suspended') {
      audioContextRef.current.resume();
    }
  }, []);

  const scheduleNextChunk = useCallback(function processQueue() {
    if (isPlayingRef.current || audioQueueRef.current.length === 0 || !audioContextRef.current) return;

    isPlayingRef.current = true;
    const chunk = audioQueueRef.current.shift()!;
    
    const buffer = audioContextRef.current.createBuffer(1, chunk.length, 24000);
    buffer.getChannelData(0).set(chunk);
    
    const source = audioContextRef.current.createBufferSource();
    source.buffer = buffer;
    source.connect(audioContextRef.current.destination);
    
    const currentTime = audioContextRef.current.currentTime;
    const startTime = Math.max(currentTime, nextPlayTimeRef.current);
    
    source.start(startTime);
    nextPlayTimeRef.current = startTime + buffer.duration;
    
    source.onended = () => {
      isPlayingRef.current = false;
      processQueue();
    };
  }, []);

  // Play Audio Chunk
  const playAudioChunk = useCallback((base64Audio: string) => {
    if (!audioContextRef.current) return;

    const binaryString = window.atob(base64Audio);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    
    // Convert PCM16 to Float32
    const int16Array = new Int16Array(bytes.buffer);
    const float32Array = new Float32Array(int16Array.length);
    for (let i = 0; i < int16Array.length; i++) {
      float32Array[i] = int16Array[i] / 32768.0;
    }

    audioQueueRef.current.push(float32Array);
    scheduleNextChunk();
  }, [scheduleNextChunk]);

  // Connect to Live API
  const connect = useCallback(async () => {
    if (!process.env.NEXT_PUBLIC_GEMINI_API_KEY) {
      console.error("Missing API Key");
      return;
    }

    ensureAudioContext();

    const client = new GoogleGenAI({ apiKey: process.env.NEXT_PUBLIC_GEMINI_API_KEY });

    // Construct schema description for the system prompt
    const schemaDescription = schema.map(table => {
      const columns = table.columns.map(col => 
        `- ${col.name} (${col.type})${col.isPrimaryKey ? ' [PK]' : ''}${col.isForeignKey ? ' [FK]' : ''}`
      ).join('\n');
      return `Table: ${table.tableName}\nColumns:\n${columns}`;
    }).join('\n\n');

    const sessionPromise = client.live.connect({
      model: "gemini-2.5-flash-native-audio-preview-09-2025",
      config: {
        responseModalities: [Modality.AUDIO],
        systemInstruction: {
          parts: [{
            text: `You are DataVoice, a helpful database assistant. 
            You have access to a database with the following schema:
            
            ${schemaDescription}
            
            When asked for data, use the 'run_sql_query' tool.
            Always write valid SQL queries compatible with the connected database.
            Be concise in your spoken responses.
            Today's date is ${new Date().toISOString().split('T')[0]}.`
          }]
        },
        tools: [{
          functionDeclarations: [{
            name: 'run_sql_query',
            description: 'Executes a SQL query against the connected database.',
            parameters: {
              type: Type.OBJECT,
              properties: {
                query: {
                  type: Type.STRING,
                  description: 'The SQL query to execute.',
                },
              },
              required: ['query'],
            },
          }]
        }]
      },
      callbacks: {
        onopen: () => {
          setIsConnected(true);
        },
        onmessage: async (message: LiveServerMessage) => {
          // Handle Audio Output
          const base64Audio = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
          if (base64Audio) {
            playAudioChunk(base64Audio);
          }

          // Handle Tool Calls
          const toolCall = message.toolCall;
          if (toolCall) {
            console.log("Tool Call Received:", toolCall);
            const functionCalls = toolCall.functionCalls;
            
            if (functionCalls && functionCalls.length > 0) {
              const call = functionCalls[0];
              if (call.name === 'run_sql_query') {
                const args = call.args as any;
                const sqlQuery = args.query;
                
                // Add system message for UI
                addMessage({
                  id: Date.now().toString(),
                  role: 'assistant',
                  content: `Executing: ${sqlQuery}`,
                  timestamp: Date.now(),
                  relatedQuery: { sql: sqlQuery, columns: [], rows: [], executionTime: 0 }
                });

                try {
                  // Execute via our Next.js API
                  const response = await fetch('/api/db/query', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ connection, query: sqlQuery }),
                  });
                  
                  const result = await response.json();
                  
                  // Update UI with results
                  addMessage({
                    id: (Date.now() + 1).toString(),
                    role: 'assistant',
                    content: "Here are the results.",
                    timestamp: Date.now(),
                    relatedQuery: result,
                    chartType: result.rows.length > 1 ? 'bar' : 'table' // Simple heuristic
                  });

                  // Send Response back to Gemini
                  const session = await sessionRef.current;
                  session.sendToolResponse({
                    functionResponses: [{
                      name: call.name,
                      id: call.id,
                      response: { result: JSON.stringify(result) }
                    }]
                  });

                } catch (error: any) {
                  console.error("Tool Execution Error", error);
                  const session = await sessionRef.current;
                  session.sendToolResponse({
                    functionResponses: [{
                      name: call.name,
                      id: call.id,
                      response: { error: error.message }
                    }]
                  });
                }
              }
            }
          }
        },
        onclose: () => {
          setIsConnected(false);
          setIsListening(false);
        },
        onerror: (error) => {
          console.error("Live API Error:", error);
          setIsConnected(false);
        }
      }
    });

    sessionRef.current = sessionPromise;
  }, [connection, addMessage, ensureAudioContext, playAudioChunk, schema]);

  // Start Recording / Streaming
  const startRecording = useCallback(async () => {
    if (!sessionRef.current) return;
    
    ensureAudioContext();
    
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      mediaStreamRef.current = stream;
      
      const source = audioContextRef.current!.createMediaStreamSource(stream);
      sourceRef.current = source;
      
      // Use ScriptProcessor for raw PCM access (AudioWorklet is better but more complex to setup in one file)
      const processor = audioContextRef.current!.createScriptProcessor(4096, 1, 1);
      processorRef.current = processor;
      
      processor.onaudioprocess = async (e) => {
        const inputData = e.inputBuffer.getChannelData(0);
        
        // Downsample to 16kHz if needed, or send as is if model supports it.
        // Gemini Live API typically accepts 16kHz PCM.
        // Simple decimation for demo (AudioContext is usually 44.1 or 48kHz)
        const targetSampleRate = 16000;
        const currentSampleRate = audioContextRef.current!.sampleRate;
        const ratio = currentSampleRate / targetSampleRate;
        const newLength = Math.floor(inputData.length / ratio);
        const pcm16 = new Int16Array(newLength);
        
        for (let i = 0; i < newLength; i++) {
          const s = Math.max(-1, Math.min(1, inputData[Math.floor(i * ratio)]));
          pcm16[i] = s < 0 ? s * 0x8000 : s * 0x7FFF;
        }
        
        // Convert to Base64
        const buffer = pcm16.buffer;
        let binary = '';
        const bytes = new Uint8Array(buffer);
        const len = bytes.byteLength;
        for (let i = 0; i < len; i++) {
          binary += String.fromCharCode(bytes[i]);
        }
        const base64Data = window.btoa(binary);

        // Send to Gemini
        const session = await sessionRef.current;
        session.sendRealtimeInput({
          media: {
            mimeType: "audio/pcm;rate=16000",
            data: base64Data
          }
        });
      };

      source.connect(processor);
      processor.connect(audioContextRef.current!.destination);
      setIsListening(true);

    } catch (err) {
      console.error("Error starting audio", err);
    }
  }, [ensureAudioContext]);

  const stopRecording = useCallback(() => {
    if (processorRef.current) {
      processorRef.current.disconnect();
      processorRef.current = null;
    }
    if (sourceRef.current) {
      sourceRef.current.disconnect();
      sourceRef.current = null;
    }
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach(track => track.stop());
      mediaStreamRef.current = null;
    }
    setIsListening(false);
  }, []);

  const disconnect = useCallback(() => {
    stopRecording();
    if (sessionRef.current) {
      sessionRef.current.then((s: any) => s.close());
      sessionRef.current = null;
    }
    setIsConnected(false);
  }, [stopRecording]);

  return {
    isConnected,
    isListening,
    connect,
    disconnect,
    startRecording,
    stopRecording
  };
}
